class TestClass:
    def __init__(self):
        print("this test is successfull :) ")